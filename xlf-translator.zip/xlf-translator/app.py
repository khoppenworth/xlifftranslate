import os
import uuid
import re
from pathlib import Path
from flask import (
    Flask, render_template, request, send_file, redirect, url_for, flash
)
from lxml import etree
import openpyxl

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = "change-me"  # set a better secret in production

def normalize_text(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"\s+", " ", s)
    s = s.strip(" .,:;!?\"'“”’")
    return s

def extract_sources_from_xlf(xlf_path: Path):
    parser = etree.XMLParser(remove_blank_text=False)
    tree = etree.parse(str(xlf_path), parser)
    root = tree.getroot()

    nsmap = root.nsmap
    trans_units = root.xpath(".//trans-unit", namespaces=nsmap) or root.findall(".//trans-unit")

    rows = []
    for tu in trans_units:
        tu_id = tu.get("id", "")
        source_el = tu.find("source")
        if source_el is None:
            source_el = tu.find("{*}source")
        if source_el is None:
            continue

        source_raw = "".join([etree.tostring(child, encoding="unicode") for child in source_el.iterchildren()])
        if source_el.text:
            source_raw = source_el.text + source_raw

        text_only_parts = re.split(r"<[^>]+>", source_raw)
        source_text_only = " ".join(p.strip() for p in text_only_parts if p.strip())

        rows.append({
            "trans_unit_id": tu_id,
            "source_raw": source_raw,
            "source_text_only": source_text_only,
        })
    return rows

def build_excel_from_rows(rows, excel_path: Path):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "translations"
    ws.append(["trans_unit_id", "source_raw", "source_text_only", "translation"])
    for r in rows:
        ws.append([
            r["trans_unit_id"],
            r["source_raw"],
            r["source_text_only"],
            ""
        ])
    wb.save(excel_path)

def load_translations_from_excel(excel_path: Path):
    wb = openpyxl.load_workbook(excel_path)
    ws = wb.active
    translations = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        tu_id, source_raw, source_text_only, translation = row
        if not tu_id:
            continue
        translations[str(tu_id)] = {
            "source_raw": source_raw or "",
            "source_text_only": source_text_only or "",
            "translation": translation or "",
            "norm_source_text_only": normalize_text(source_text_only or "")
        }
    return translations

def apply_translations_to_xlf(original_xlf: Path, translations: dict, output_path: Path):
    parser = etree.XMLParser(remove_blank_text=False)
    tree = etree.parse(str(original_xlf), parser)
    root = tree.getroot()

    trans_units = root.xpath(".//trans-unit", namespaces=root.nsmap) or root.findall(".//trans-unit")

    for tu in trans_units:
        tu_id = tu.get("id", "")
        if tu_id not in translations:
            continue
        tinfo = translations[tu_id]
        user_tr = tinfo["translation"].strip()
        if not user_tr:
            continue

        source_el = tu.find("source")
        if source_el is None:
            source_el = tu.find("{*}source")
        if source_el is None:
            continue

        source_raw = "".join([etree.tostring(child, encoding="unicode") for child in source_el.iterchildren()])
        if source_el.text:
            source_raw = source_el.text + source_raw

        chunks = re.split(r"(<[^>]+>)", source_raw)
        filled_once = False
        new_chunks = []
        for chunk in chunks:
            if not chunk:
                continue
            if chunk.startswith("<") and chunk.endswith(">"):
                new_chunks.append(chunk)
            else:
                if not filled_once:
                    leading = chunk[:len(chunk) - len(chunk.lstrip())]
                    trailing = chunk[len(chunk.rstrip()):]
                    new_chunks.append(f"{leading}{user_tr}{trailing}")
                    filled_once = True
                else:
                    new_chunks.append(chunk)

        new_inner = "".join(new_chunks)
        for child in list(source_el):
            source_el.remove(child)
        source_el.text = None

        frag = etree.fromstring(f"<wrapper>{new_inner}</wrapper>")
        source_el.text = frag.text
        for sub in frag:
            source_el.append(sub)

    tree.write(str(output_path), encoding="utf-8", xml_declaration=True)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        xlf_file = request.files.get("xlf_file")
        if not xlf_file:
            flash("Please upload an XLF file.")
            return redirect(url_for("index"))

        job_id = str(uuid.uuid4())
        job_dir = UPLOAD_DIR / job_id
        job_dir.mkdir(exist_ok=True)

        xlf_path = job_dir / "original.xlf"
        xlf_file.save(xlf_path)

        rows = extract_sources_from_xlf(xlf_path)
        excel_path = job_dir / "xlf_sources.xlsx"
        build_excel_from_rows(rows, excel_path)

        return redirect(url_for("translate", job_id=job_id))

    return render_template("index.html")

@app.route("/translate/<job_id>", methods=["GET", "POST"])
def translate(job_id):
    job_dir = UPLOAD_DIR / job_id
    if not job_dir.exists():
        flash("Job not found.")
        return redirect(url_for("index"))

    excel_path = job_dir / "xlf_sources.xlsx"
    xlf_path = job_dir / "original.xlf"

    if request.method == "POST":
        excel_file = request.files.get("excel_file")
        if not excel_file:
            flash("Please upload the filled Excel file.")
            return redirect(url_for("translate", job_id=job_id))

        filled_excel_path = job_dir / "xlf_sources_filled.xlsx"
        excel_file.save(filled_excel_path)

        translations = load_translations_from_excel(filled_excel_path)
        output_xlf = job_dir / "translated.xlf"
        apply_translations_to_xlf(xlf_path, translations, output_xlf)

        return send_file(output_xlf, as_attachment=True, download_name="translated.xlf")

    return render_template("translate.html", job_id=job_id,
                           excel_available=excel_path.exists())

@app.route("/download-excel/<job_id>")
def download_excel(job_id):
    job_dir = UPLOAD_DIR / job_id
    excel_path = job_dir / "xlf_sources.xlsx"
    if not excel_path.exists():
        flash("Excel not found.")
        return redirect(url_for("index"))
    return send_file(excel_path, as_attachment=True, download_name="xlf_sources.xlsx")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
